<?php  if ( !defined('BASEPATH')) exit('No direct script access allowed');

$config['recaptcha_web_key'] = "";
$config['recaptcha_secret_key'] = "";