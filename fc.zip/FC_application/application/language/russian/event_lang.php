<?php
$lang['event_invoice_overdue'] = 'Оплата счета {invoice_number} <span class="label label-important">является просроченной </span>';
$lang['event_project_overdue'] = 'Проект {project_number} <span class="label label-important"> достиг конечного срока </span>';
$lang['event_subscription_new_invoice'] = '<span class="label label-warning">Новая счет-фактура</span> необходима для подписки {subscription_number}';
