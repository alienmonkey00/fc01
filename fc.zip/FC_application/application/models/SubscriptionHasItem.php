<?php

class SubscriptionHasItem extends ActiveRecord\Model {
    static $table_name = 'subscription_has_items';
  
}
